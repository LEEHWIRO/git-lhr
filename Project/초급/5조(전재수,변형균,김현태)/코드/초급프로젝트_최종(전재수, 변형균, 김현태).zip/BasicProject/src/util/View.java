package util;

public class View {

	public static final int HOME = 0;
	public static final int LOGIN = 1; 
	public static final int JOIN = 2;
	public static final int USERMENU = 3;
	public static final int ADMINMENU = 4;
	
}

package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JDBCUtil {
	private JDBCUtil () {
		
	}
	private static JDBCUtil instance;
	public static JDBCUtil getInstance() {
		if(instance == null) {
			instance = new JDBCUtil();
		}
		return instance;
	}
	
	
	String url 	= "jdbc:oracle:thin:@192.168.43.174:1521:xe";
	String id	= "admin";
	String pw	= "java";
	String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";
	
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	

	public Map<String, Object> selectOne(String sql){

		Map<String, Object> row = null;
		try {
			con = DriverManager.getConnection (url,id,pw);
			ps = con.prepareStatement (sql);
			rs = ps.executeQuery ();
			ResultSetMetaData metaData = rs.getMetaData ();
			int columnCount = metaData.getColumnCount ();
			while(rs.next()) {//true
				row = new HashMap<>();
				for(int i = 1 ; i <= columnCount ; i++) {
					row.put (metaData.getColumnName (i), rs.getObject (i));//접근 시 1번부터 시작함.
				}//close for
			}//close if
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
//			객체 반환
			if( rs != null ) try { rs.close (); } catch(Exception e) {}
			if( ps != null ) try { ps.close (); } catch(Exception e) {}
			if( con != null ) try { con.close (); } catch(Exception e) {}
		}//close finally
		return row;		
	}
	public Map<String, Object> selectOne(String sql, List<Object> param){
		Map<String, Object> row = null;
		try {
			con = DriverManager.getConnection (url,id,pw);
			ps = con.prepareStatement (sql);
			for(int i = 0 ; i < param.size () ; i++) {
				ps.setObject ( i + 1 , param.get (i) );//물음표는 1부터 시작하므로 +1을 함.
			}
			rs =ps.executeQuery ();
			ResultSetMetaData metaData = rs.getMetaData ();
			int columnCount = metaData.getColumnCount ();
			while(rs.next()) {
				row = new HashMap<>();
				for(int i = 1 ; i <= columnCount ; i++) {
					row.put (metaData.getColumnName (i), rs.getObject(i));
				}//close for
			}//close if
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
//			객체 반환
			if( rs != null ) try { rs.close (); } catch(Exception e) {}
			if( ps != null ) try { ps.close (); } catch(Exception e) {}
			if( con != null ) try { con.close (); } catch(Exception e) {}
		}//close finally
		return row;
	}
	
	public List<Map<String, Object>> selectList(String sql){
		List<Map<String, Object>> list = new ArrayList<>();
		try {
			con = DriverManager.getConnection (url,id,pw);
			ps = con.prepareStatement (sql);
			rs = ps.executeQuery ();
			ResultSetMetaData metaData = rs.getMetaData ();
			int columnCount = metaData.getColumnCount ();
			while(rs.next()) {
				HashMap<String, Object> row = new HashMap<>();
				for(int i = 1 ; i <= columnCount ; i++) {
					row.put (metaData.getColumnName (i), rs.getObject (i));
				}//close for
				list.add (row);
			}//close while
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
//			객체 반환
			if( rs != null ) try { rs.close (); } catch(Exception e) {}
			if( ps != null ) try { ps.close (); } catch(Exception e) {}
			if( con != null ) try { con.close (); } catch(Exception e) {}
		}//close finally
		
		return list;
	}
	public List<Map<String, Object>> selectList(String sql, List<Object> param){
		List<Map<String, Object>> list = new ArrayList<>();
		try {
			con = DriverManager.getConnection (url,id,pw);
			ps = con.prepareStatement (sql);
			for(int i = 0 ; i < param.size () ; i++) {
				ps.setObject ( i + 1 , param.get (i) );//물음표는 1부터 시작하므로 +1을 함.
			}
			rs = ps.executeQuery ();//resultSet
			ResultSetMetaData metaData = rs.getMetaData ();
			int columnCount = metaData.getColumnCount ();
			while(rs.next ()) {
				HashMap<String, Object> row = new HashMap<>();
				for(int i = 1 ; i <= columnCount ; i++) {//1부터 시작해야함(0부터 시작하면 오류남)
					row.put (metaData.getColumnName (i), rs.getObject (i));//디비는 1부터 인덱스 계산을 함.
				}
				list.add (row);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
//			객체 반환
			if( rs != null ) try { rs.close (); } catch(Exception e) {}
			if( ps != null ) try { ps.close (); } catch(Exception e) {}
			if( con != null ) try { con.close (); } catch(Exception e) {}
		}
		
		
		return list;
	}
	
	public int update(String sql) {
//		리턴 타입 변수 생성
		int result = 0;
		try {
//			DB 연결
			con = DriverManager.getConnection(url,id,pw);
			
//			쿼리 실행
			ps = con.prepareStatement (sql);
			
//			쿼리 결과 삽입
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
//			객체 반환
//			if( rs != null ) try { rs.close (); } catch(Exception e) {}
			if( ps != null ) try { ps.close (); } catch(Exception e) {}
			if( con != null ) try { con.close (); } catch(Exception e) {}
		}//close finally
		return result;
	}
	
	public int update(String sql, List<Object> param) {
		int result = 0;
		try {
			con = DriverManager.getConnection (url,id,pw);
			ps = con.prepareStatement (sql);
			for(int i = 0 ; i < param.size () ; i++) {
				ps.setObject ( i + 1 , param.get (i) );//물음표는 1부터 시작하므로 +1을 함.
			}
			
			result = ps.executeUpdate ();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
//			객체 반환
//			if( rs != null ) try { rs.close (); } catch(Exception e) {}
			if( ps != null ) try { ps.close (); } catch(Exception e) {}
			if( con != null ) try { con.close (); } catch(Exception e) {}
		}//close finally
		return result;
	}
}
